// Content script for LinkedIn Profile Downloader
// Runs on LinkedIn profile pages

let isProcessing = false;

// Listen for messages from popup
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.action === 'checkPage') {
    const pageInfo = getPageInfo();
    sendResponse(pageInfo);
  } else if (message.action === 'downloadProfile') {
    downloadProfile(message.config);
    sendResponse({ success: true });
  } else if (message.action === 'extractProfileData') {
    const data = extractProfileData();
    sendResponse({ success: true, data: data });
  }
  return true;
});

function getPageInfo() {
  const url = window.location.href;
  const isProfilePage = url.includes('/in/') && !url.includes('/search/');
  const isRecruiterPage = url.includes('/talent/') || url.includes('/recruiter/');

  let candidateName = '';

  if (isProfilePage || isRecruiterPage) {
    // Try to get the candidate name from the page
    candidateName = getCandidateName();
  }

  return {
    url: url,
    isProfilePage: isProfilePage,
    isRecruiterPage: isRecruiterPage,
    candidateName: candidateName
  };
}

function getCandidateName() {
  // Try multiple selectors for different LinkedIn page types
  const nameSelectors = [
    // Regular profile page
    'h1.text-heading-xlarge',
    '.pv-top-card--list li:first-child',
    '.text-heading-xlarge',
    // Recruiter/Sales Navigator
    '.profile-topcard-person-entity__name',
    '.artdeco-entity-lockup__title',
    // Fallback selectors
    'h1[class*="name"]',
    '.pv-text-details__left-panel h1',
    '[data-anonymize="person-name"]'
  ];

  for (const selector of nameSelectors) {
    try {
      const element = document.querySelector(selector);
      if (element) {
        const name = element.textContent.trim();
        if (name && name.length > 1 && name.length < 100) {
          return sanitizeFilename(name);
        }
      }
    } catch (e) {
      // Continue to next selector
    }
  }

  // Try to extract from page title
  const title = document.title;
  if (title && title.includes('|')) {
    const name = title.split('|')[0].trim();
    if (name && !name.toLowerCase().includes('linkedin')) {
      return sanitizeFilename(name);
    }
  }

  return 'LinkedIn_Profile';
}

function downloadProfile(config) {
  if (isProcessing) {
    sendStatusUpdate('Already processing...', 'info');
    return;
  }

  isProcessing = true;
  sendStatusUpdate('Preparing profile download...', 'info');

  const candidateName = getCandidateName();
  const profileUrl = window.location.href;

  // Strategy 1: Look for LinkedIn's native "Save to PDF" or "More" button
  const savedToPdf = tryNativeSaveToPdf();

  if (!savedToPdf) {
    // Strategy 2: Use print-to-PDF approach
    sendStatusUpdate('Opening print dialog (save as PDF)...', 'info');
    triggerPrintToPdf(candidateName, config);
  }

  // Extract profile data for CSV/Excel export
  const profileData = extractProfileData();

  // Send data to background script for storage
  chrome.runtime.sendMessage({
    action: 'storeProfileData',
    data: {
      name: candidateName,
      url: profileUrl,
      extractedAt: new Date().toISOString(),
      ...profileData
    }
  });

  isProcessing = false;
}

function tryNativeSaveToPdf() {
  // Look for LinkedIn's "More" dropdown which contains "Save to PDF"
  const moreButtons = document.querySelectorAll(
    'button[aria-label*="More actions"], ' +
    '.pvs-profile-actions button[aria-label*="More"], ' +
    '.pv-top-card-v2-ctas button[aria-label*="More"], ' +
    '[data-control-name="more_actions"]'
  );

  for (const button of moreButtons) {
    if (isVisible(button)) {
      console.log('Found More button, clicking...');
      button.click();

      // Wait for dropdown to appear, then look for Save to PDF
      setTimeout(() => {
        const savePdfOptions = document.querySelectorAll(
          '[data-control-name="save_to_pdf"], ' +
          'div[aria-label*="Save to PDF"], ' +
          'span:contains("Save to PDF")'
        );

        for (const option of savePdfOptions) {
          if (isVisible(option)) {
            console.log('Found Save to PDF option, clicking...');
            option.click();
            sendStatusUpdate('Triggered LinkedIn Save to PDF', 'success');
            return true;
          }
        }

        // Close dropdown if Save to PDF not found
        document.body.click();
      }, 500);

      return false; // Will handle async
    }
  }

  return false;
}

function triggerPrintToPdf(candidateName, config) {
  // Prepare page for printing
  // Hide non-essential elements for cleaner PDF
  const elementsToHide = [
    '.global-nav',
    '.msg-overlay-list-bubble',
    '.scaffold-layout__aside',
    '.ad-banner-container',
    '[data-test-id="aside"]'
  ];

  const hiddenElements = [];

  elementsToHide.forEach(selector => {
    const elements = document.querySelectorAll(selector);
    elements.forEach(el => {
      if (el && el.style) {
        hiddenElements.push({ element: el, display: el.style.display });
        el.style.display = 'none';
      }
    });
  });

  // Trigger print dialog (user saves as PDF)
  setTimeout(() => {
    window.print();

    // Restore hidden elements after a delay
    setTimeout(() => {
      hiddenElements.forEach(item => {
        item.element.style.display = item.display;
      });
      sendStatusUpdate(`Save the PDF as: ${candidateName}.pdf`, 'success');
    }, 1000);
  }, 500);
}

function extractProfileData() {
  const data = {
    name: '',
    headline: '',
    location: '',
    about: '',
    currentCompany: '',
    currentTitle: '',
    experience: [],
    education: [],
    skills: [],
    profileUrl: window.location.href
  };

  try {
    // Name
    data.name = getCandidateName();

    // Headline
    const headlineEl = document.querySelector(
      '.text-body-medium.break-words, ' +
      '.pv-top-card--list-bullet, ' +
      '[data-anonymize="headline"]'
    );
    if (headlineEl) {
      data.headline = headlineEl.textContent.trim();
    }

    // Location
    const locationEl = document.querySelector(
      '.text-body-small.inline.t-black--light.break-words, ' +
      '.pv-top-card--list.pv-top-card--list-bullet span, ' +
      '[data-anonymize="location"]'
    );
    if (locationEl) {
      data.location = locationEl.textContent.trim();
    }

    // About section
    const aboutEl = document.querySelector(
      '#about ~ .display-flex .inline-show-more-text, ' +
      '.pv-about__summary-text, ' +
      '[data-anonymize="about-summary"]'
    );
    if (aboutEl) {
      data.about = aboutEl.textContent.trim().substring(0, 2000);
    }

    // Experience
    const experienceSection = document.querySelector('#experience');
    if (experienceSection) {
      const experienceItems = experienceSection.parentElement.querySelectorAll('li.artdeco-list__item');
      experienceItems.forEach((item, index) => {
        if (index < 10) { // Limit to 10 experiences
          const titleEl = item.querySelector('.t-bold span[aria-hidden="true"]');
          const companyEl = item.querySelector('.t-normal span[aria-hidden="true"]');
          const durationEl = item.querySelector('.t-black--light span[aria-hidden="true"]');

          const exp = {
            title: titleEl ? titleEl.textContent.trim() : '',
            company: companyEl ? companyEl.textContent.trim() : '',
            duration: durationEl ? durationEl.textContent.trim() : ''
          };

          if (exp.title || exp.company) {
            data.experience.push(exp);

            // Set current company/title from first experience
            if (index === 0) {
              data.currentTitle = exp.title;
              data.currentCompany = exp.company;
            }
          }
        }
      });
    }

    // Education
    const educationSection = document.querySelector('#education');
    if (educationSection) {
      const educationItems = educationSection.parentElement.querySelectorAll('li.artdeco-list__item');
      educationItems.forEach((item, index) => {
        if (index < 5) { // Limit to 5 education entries
          const schoolEl = item.querySelector('.t-bold span[aria-hidden="true"]');
          const degreeEl = item.querySelector('.t-normal span[aria-hidden="true"]');

          const edu = {
            school: schoolEl ? schoolEl.textContent.trim() : '',
            degree: degreeEl ? degreeEl.textContent.trim() : ''
          };

          if (edu.school) {
            data.education.push(edu);
          }
        }
      });
    }

    // Skills
    const skillsSection = document.querySelector('#skills');
    if (skillsSection) {
      const skillItems = skillsSection.parentElement.querySelectorAll('.t-bold span[aria-hidden="true"]');
      skillItems.forEach((item, index) => {
        if (index < 20) { // Limit to 20 skills
          const skill = item.textContent.trim();
          if (skill && !data.skills.includes(skill)) {
            data.skills.push(skill);
          }
        }
      });
    }

  } catch (error) {
    console.error('Error extracting profile data:', error);
  }

  return data;
}

function isVisible(element) {
  return !!(element.offsetWidth || element.offsetHeight || element.getClientRects().length);
}

function sanitizeFilename(name) {
  return name
    .replace(/[<>:"/\\|?*]/g, '')
    .replace(/\s+/g, '_')
    .substring(0, 100);
}

function sendStatusUpdate(text, type) {
  chrome.runtime.sendMessage({
    action: 'updateStatus',
    text: text,
    type: type
  });
}

// Add a floating download button to profile pages
function addDownloadButton() {
  // Check if already added
  if (document.getElementById('linkedin-profile-downloader-btn')) {
    return;
  }

  // Only add on profile pages
  if (!window.location.href.includes('/in/')) {
    return;
  }

  const button = document.createElement('button');
  button.id = 'linkedin-profile-downloader-btn';
  button.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
      <polyline points="7 10 12 15 17 10"></polyline>
      <line x1="12" y1="15" x2="12" y2="3"></line>
    </svg>
    <span>Download Profile</span>
  `;

  button.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    z-index: 9999;
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 12px 20px;
    background: linear-gradient(135deg, #0077B5 0%, #00A0DC 100%);
    color: white;
    border: none;
    border-radius: 24px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(0, 119, 181, 0.4);
    transition: all 0.2s ease;
  `;

  button.addEventListener('mouseenter', () => {
    button.style.transform = 'translateY(-2px)';
    button.style.boxShadow = '0 6px 16px rgba(0, 119, 181, 0.5)';
  });

  button.addEventListener('mouseleave', () => {
    button.style.transform = 'translateY(0)';
    button.style.boxShadow = '0 4px 12px rgba(0, 119, 181, 0.4)';
  });

  button.addEventListener('click', () => {
    downloadProfile({});
  });

  document.body.appendChild(button);
}

// Initialize when page loads
function initialize() {
  console.log('LinkedIn Profile Downloader: Content script loaded');

  // Wait for page to fully load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', addDownloadButton);
  } else {
    setTimeout(addDownloadButton, 1000);
  }

  // Re-add button on navigation (LinkedIn is a SPA)
  let lastUrl = location.href;
  new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
      lastUrl = url;
      setTimeout(addDownloadButton, 1500);
    }
  }).observe(document, { subtree: true, childList: true });
}

initialize();
